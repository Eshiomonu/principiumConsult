<!DOCTYPE html>
<html>
<head><title>Thank You</title></head>
<body>
  <h2>Thank you for registering!</h2>
  <p>Please check your email for confirmation and next steps.</p>
</body>
</html>