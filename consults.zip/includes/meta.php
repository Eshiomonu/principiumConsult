<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <!-- Meta description -->
  <meta name="description" content="Expert consulting services specializing in strategic planning and portfolio optimization for the hospitality industry. We provide global insights across a wide range of hotel properties, including branded full-service and select-service hotels, resorts, and independently owned establishments.">

  <!-- Meta keywords (optional, less relevant for modern SEO) -->
  <meta name="keywords" content="hotel consulting, strategic planning, portfolio optimization, hotel properties, hospitality industry, resorts, branded hotels, independent hotels, global consulting">

  <!-- Meta robots (to control search engine crawling) -->
  <meta name="robots" content="index, follow">

  <title>Principium Consults - Expert Consulting Services for the Hospitality Industry</title>


  <!-- Favicons -->
  <link rel="apple-touch-icon" sizes="180x180" href="./assets/img/>
<link rel=" icon" type="image/png" sizes="32x32" href="./assets/img/favicon/favicon-32x32.png">
  <link rel="icon" type="image/png" sizes="16x16" href="./assets/img/favicon/favicon-16x16.png">
  <link rel="manifest" href="./assets/img/favicon/site.webmanifest">

  <!-- Fonts -->
  <link href="https://fonts.googleapis.com" rel="preconnect">
  <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Raleway:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

  <!-- Vendor CSS Files -->
  <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="assets/vendor/aos/aos.css" rel="stylesheet">
  <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

  <!-- Main CSS File -->
  <link href="assets/css/main.css" rel="stylesheet">
</head>